<?php

require './front_connection.php';
/* * *********Above code default in all pages*********** */

$msg->info("Your transaction cancelled. Please try again", "index.php");
?>